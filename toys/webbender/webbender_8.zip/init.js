chrome.browserAction.onClicked.addListener(function (tab) {
  console.log('WebBender, ACTIVATE!')

  let pathRegular = chrome.runtime.getURL('Dongle/Dongle-Regular.woff2')
  let pathBold = chrome.runtime.getURL('Dongle/Dongle-Bold.woff2')
  let pathLight = chrome.runtime.getURL('Dongle/Dongle-Regular.woff2')
  let fontFaces = `
    @font-face {
      font-family: 'Dongle';
      font-style: regular;
      font-weight: 400;
      src: url('${pathRegular}') format('woff2');
    }
    @font-face {
      font-family: 'Dongle';
      font-style: bold;
      font-weight: 400;
      src: url('${pathBold}') format('woff2');
    }
    @font-face {
      font-family: 'Dongle';
      font-style: thin;
      font-weight: 400;
      src: url('${pathLight}') format('woff2');
    }
  `
	chrome.tabs.insertCSS(tab.ib, { code: fontFaces })
	chrome.tabs.insertCSS(tab.ib, { file: 'codemirror.min.css' })
  chrome.tabs.insertCSS(tab.ib, { file: 'style.css' })

	chrome.tabs.executeScript(tab.ib, { file: 'codemirror.min.js' })
	chrome.tabs.executeScript(tab.ib, { file: 'javascript.min.js' })
	chrome.tabs.executeScript(tab.ib, { file: 'lib.js' })
	chrome.tabs.executeScript(tab.ib, { file: 'app.js' })

})

let empty = () => {
  alert('This is an empty glitch. Click on * to enter edit mode.')
  /*
  runForever(fn, t)
  selectOne(query)
  selectAll(query)
  selectStuff()
  setStyle(el, key, value)
  isInViewport(element)
  oscillate(phase, frequency, amplitute)
  random(min, max)
  map(x, in_min, in_max, out_min, out_max)
  createElement(tagName, properties, content)
  whenKeyIsPressed(key, fn)
  whenKeyIsPressedOnce(key, fn)
  whenMouseMoves(fn)
  whenMouseClicks(fn)
  whenMouseClicksOnce(fn)
  getElementAt(x, y)
  getAllElementsAt(x, y)
  */
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('Run when is installed')
  chrome.storage.local.set({ empty: empty.toString() })
  console.log('Added empty default glitch')
})
