let elements = document.querySelectorAll('*')
for (let i = 0; i < elements.length; i++) {
    let el = elements[i]
    el.setAttribute('contenteditable', "true")
}
