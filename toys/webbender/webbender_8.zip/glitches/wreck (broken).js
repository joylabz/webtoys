() => {
  let tags = [
    'a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'img', 'hr', 'br', 'span', 'li',
    'svg', 'audio', 'video', 'iframe', 'embed', 'path', 'td', 'th', 'tl',
    'input', 'select', 'textarea', 'radio', 'button', 'canvas', 'i', 'img'
  ]
  let app = document.querySelector('#appxxx')

  // Wrecking ball
  let ball = document.createElement('div')
  ball.id = 'ball'

  ball.dataset['top'] = 20
  ball.dataset['left'] = 50
  ball.dataset['speedTop'] = 0.5 + Math.random()*0.5
  ball.dataset['speedLeft'] = 0.5 + Math.random()*0.5

  ball.style.top = `${ball.dataset['top']}vw`
  ball.style.left = `${ball.dataset['left']}vh`
  ball.style.width = `2vw`
  ball.style.height = `2vw`
  ball.style.background = `hsl(${Math.random()*360}, 100%, 50%)`

  setInterval(() => {
    let top = parseFloat(ball.dataset['top'])
    let left = parseFloat(ball.dataset['left'])
    let speedTop = parseFloat(ball.dataset['speedTop'])
    let speedLeft = parseFloat(ball.dataset['speedLeft'])

    top += speedTop
    left += speedLeft

    if (top < 0 || top > 100) {
      ball.dataset['speedTop'] = -speedTop
    }
    if (left < 0 || left > 100) {
      ball.dataset['speedLeft'] = -speedLeft
    }

    ball.dataset['top'] = top
    ball.dataset['left'] = left

    ball.style.top = `${top}vh`
    ball.style.left = `${left}vw`
  }, 1000/30)

  setInterval(() => {
    let bounds = ball.getBoundingClientRect()
    let elements = document.elementsFromPoint(bounds.left, bounds.top)
    let el = elements.find(e => {
      return tags.indexOf(e.tagName.toLowerCase()) !== -1
    })
    let pad = elements.find(e => e.id === 'paddle')
    if (pad) {
      let top = parseFloat(ball.dataset['top'])
      let speedTop = parseFloat(ball.dataset['speedTop'])
      ball.dataset['speedTop'] = -speedTop
      ball.dataset['top'] = top - speedTop
    } else if (el) {
      el.style.transition = 'opacity 0.1s'
      el.style.opacity = 0
      setTimeout(() => el.remove(), 100)

      let top = parseFloat(ball.dataset['top'])
      let left = parseFloat(ball.dataset['left'])
      let speedTop = parseFloat(ball.dataset['speedTop'])
      let speedLeft = parseFloat(ball.dataset['speedLeft'])

      ball.dataset['speedTop'] = -speedTop
      ball.dataset['speedLeft'] = -speedLeft
      ball.dataset['top'] = top - speedTop
      ball.dataset['left'] = left - speedTop
    }
  }, 1000/20)

  document.addEventListener('mousemove', (e) => {
    let left = map(e.clientX, 0, window.innerWidth, 0, 100)
    paddle.dataset['left'] = left
    paddle.style.left = `${left}vw`
  })

  // Paddle
  let paddle = document.createElement('div')
  paddle.id = 'paddle'

  paddle.dataset['top'] = 5
  paddle.dataset['left'] = 50

  paddle.style.top = `${paddle.dataset['top']}vw`
  paddle.style.left = `${paddle.dataset['left']}vw`

  app.appendChild(paddle)
  app.appendChild(ball)
}
