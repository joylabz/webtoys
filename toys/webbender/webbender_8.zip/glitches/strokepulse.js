() => {
  clearInterval(window.pulseInterval || 0)
  window.pulseInterval = setInterval(() => {
  	let paths = document.querySelectorAll('svg path')
    Array.from(paths).forEach((p) => {
      if (p.attributes['stroke-width']) {
        p.attributes['stroke-width'].nodeValue = map(
          Math.sin(Date.now()/1000),
          -1, 1,
          3, 15
        )
      }
    })
  }, 20)
}
