() => {
  clearInterval(window.pulseInterval || 0)
  window.pulseInterval = setInterval(() => {
  	let paths = document.querySelectorAll('svg path')
    Array.from(paths).forEach((p, i) => {
      p.attributes['stroke-width'].nodeValue = map(
        Math.sin((Date.now()/1000) + (i*0.2)),
        -1, 1,
        3, 15
      )
    })
  }, 20)
}
