() => {
  mousePosition = [0, 0]
  window.addEventListener('mousemove', (e) => {
    mousePosition = [e.screenX, e.screenY]
  })
  clearInterval(window.pulseInterval || 0)
  window.pulseInterval = setInterval(() => {
  	let paths = document.querySelectorAll('svg path')
    Array.from(paths).forEach((p, i) => {
      let bounds = p.getBoundingClientRect()
      let centerX = bounds.left + (bounds.width/2)
      let centerY = bounds.top + (bounds.height/2)
      let dx = Math.abs(centerX - mousePosition[0])
      let dy = Math.abs(centerY - mousePosition[1])
      let d = Math.hypot(dx, dy)
      p.attributes['stroke-width'].nodeValue = (1 / d) * window.innerWidth
    })
  }, 20)
}
