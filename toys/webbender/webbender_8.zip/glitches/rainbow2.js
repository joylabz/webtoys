let everything = document.querySelectorAll('*')
for (let i = 0; i < everything.length; i++) {
  let thing = everything[i]
  let hue = map(i, 0, everything.length-1,
                0, 360)
  thing.style.background =
    `hsl(${hue}, 100%, 50%)`
}
