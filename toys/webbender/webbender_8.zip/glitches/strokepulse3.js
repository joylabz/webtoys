() => {
  clearInterval(window.pulseInterval || 0)
  window.pulseInterval = setInterval(() => {
  	let paths = document.querySelectorAll('svg path')
    Array.from(paths).forEach((p, i) => {
      p.attributes['stroke-width'].nodeValue = map(
        2*Math.sin((5*Date.now()/1000) + (i*0.2)),
        -2, 2,
        3, 15
      )
    })
  }, 20)
}
