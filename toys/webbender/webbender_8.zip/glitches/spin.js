() => {
  // Find all the elements that usually have words
  let everything = document.querySelectorAll(
    ['a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'i'].join(', ')
  )

  let allWords = []
  // Wrap all the words on a span.wordxxx
  for (let i = 0; i < everything.length; i++) {
    let thing = everything[i]
    let text = thing.innerText.trim()
    let words = text.split(' ')
    words = words.filter(w => w)
    allWords = allWords.concat(words)
    let wrappedWords = words.map(w => `<span class="wordxxx">${w} </span>`)
    thing.innerHTML = wrappedWords.join('')
  }
  let t = 0
  window.spin = setInterval(() => {
	let wordxxx = document.querySelectorAll('span.wordxxx, img')
    for (let i = 0; i < wordxxx.length; i++) {
      if (isInViewport(wordxxx[i])) {
      	let phase = t + i*5
        wordxxx[i].style.display = 'inline-block'
        wordxxx[i].style.transform = `rotate(${phase}deg)`
      }
    }
    t += 1
    t %= 360
  }, 33)
}
