() => {
  let everything = selectStuff()
  setInterval(() => {
    for (let i = 0; i < Math.min(200, everything.length); i++) {
      let thing = everything[i]
      let thingBound = thing.getBoundingClientRect()
      let w = window.innerWidth
      let h = window.innerHeight
      let t = Date.now() * 0.0001
      let phase = map(i, 0, everything.length, 0, 0.1*Math.PI)
      let left = map(Math.sin(5*(t + phase)), -1, 1, 0, w)
      let top = map(Math.cos(7*(t + phase)), -1, 1, 0, h)
      thing.style.top = `${top}px`
      thing.style.left = `${left}px`
      thing.style.position = `absolute`
    }
  }, 33)
}
