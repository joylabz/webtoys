() => {
  function rad(degrees) { return degrees * (Math.PI/180) }
  function lerp(a, b, n) { return (1 - n) * a + n * b }

  let el, hovering

  function onMouseMove(e) {
    let underTheMouse = document.elementsFromPoint(e.clientX, e.clientY)
    el = Array.from(underTheMouse).find(h => {
      return h.id !== 'appxxx' && h.id !== 'hovering'
    })
    if (!el) return false

    let bounds = el.getBoundingClientRect()
    hovering = document.querySelector('#hovering')
    if (!hovering) {
      hovering = document.createElement('div')
      hovering.id = 'hovering'
      hovering.style.position = 'absolute'
      hovering.style.transition = 'all 0.2s'
      hovering.style.background = 'rgba(255, 0, 0, 0.5)'
      hovering.style.pointer = 'none'
      let app = document.querySelector('#appxxx')
      app.appendChild(hovering)
    }

    hovering.style.top = `${bounds.top}px`
    hovering.style.left = `${bounds.left}px`
    hovering.style.width = `${bounds.width}px`
    hovering.style.height = `${bounds.height}px`
  }
  document.addEventListener('mousemove', onMouseMove)

  let a, b // a catches b

  function onMouseDown(e) {
    if (!a) {
      console.log('picked a')
      a = el
      return false
    }
    console.log('picked b')
    b = el
    document.removeEventListener('mousedown', onMouseDown)
    document.removeEventListener('mousemove', onMouseMove)
    hovering.remove()

    // POLAR COORDINATES [ size, angle ]
    let speedA = [3, rad(180*Math.random())]
    let speedB = [3, rad(180*Math.random())]

    let boundsA = a.getBoundingClientRect()
    let boundsB = b.getBoundingClientRect()
    a.style.position = 'fixed';
    a.style.display = 'block';
    a.style.top = `${boundsA.top}px`
    a.style.left = `${boundsA.left}px`
    a.style.width = `${boundsA.width}px`
    a.style.height = `${boundsA.height}px`
    a.style.zIndex = '999'

    b.style.position = 'fixed';
    b.style.display = 'block';
    b.style.top = `${boundsB.top}px`
    b.style.left = `${boundsB.left}px`
    b.style.width = `${boundsB.width}px`
    b.style.height = `${boundsB.height}px`
    b.style.zIndex = '998'

    setInterval(() => {
      let boundsA = a.getBoundingClientRect()
      let boundsB = b.getBoundingClientRect()

      // Distance vector between a -> b
      let d = [
        boundsB.left - boundsA.left,
        boundsB.top - boundsA.top
      ]
      // distance angle
      let da = Math.atan2(d[0], d[1])
      speedA[1] = da

      let vax = speedA[0] * Math.sin(speedA[1])
      let vay = speedA[0] * Math.cos(speedA[1])

      let vbx = speedB[0] * Math.sin(speedB[1])
      let vby = speedB[0] * Math.cos(speedB[1])

      a.style.top = `${boundsA.top + vay}px`
      a.style.left = `${boundsA.left + vax}px`

      b.style.top = `${boundsB.top + vby}px`
      b.style.left = `${boundsB.left + vbx}px`

    }, 33)
  }

  document.addEventListener('mousedown', onMouseDown)
}
