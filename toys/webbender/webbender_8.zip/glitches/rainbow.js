let everything = document.querySelectorAll(['a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'img', 'hr', 'br', 'span', 'li',
'svg', 'audio', 'video', 'iframe', 'embed', 'path', 'td', 'th', 'tl',
'input', 'select', 'textarea', 'radio', 'button', 'canvas'
].join(', '))
setInterval(() => {
  for(let i = 0; i < everything.length; i++) {
    let phase = ( (i*30) + (Date.now() * 0.1) ) % 360
    everything[i].style.background = `hsl(${phase}, 100%, 50%)`
  }
}, 33)
