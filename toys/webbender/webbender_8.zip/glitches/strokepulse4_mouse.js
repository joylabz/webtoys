() => {
  window.addEventListener('mousemove', (e) => {
    mouseInterference = e.screenX * 0.01 + e.screenY * 0.01
  })
  clearInterval(window.pulseInterval || 0)
  window.pulseInterval = setInterval(() => {
  	let paths = document.querySelectorAll('svg path')
    Array.from(paths).forEach((p, i) => {
      p.attributes['stroke-width'].nodeValue = map(
        Math.sin(mouseInterference),
        -1, 1,
        3, 15
      )
    })
  }, 20)
}
