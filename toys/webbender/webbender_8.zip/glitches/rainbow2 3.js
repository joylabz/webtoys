() => {
  let everything = document.querySelectorAll('img')
  setInterval(() => {
    for (let i = 0; i < everything.length; i++) {
      let thing = everything[i]
      let hue = map(
        Math.sin(i*30 + Date.now()*0.001),
        -1, 1,
        0, 360
      )
      thing.style.filter = `hue-rotate(${hue}deg)`
    }
  }, 33)
}
