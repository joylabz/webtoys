() => {
  let everything = selectStuff()
  setInterval(() => {
    for(let i = 0; i < everything.length; i++) {
      let phase = Math.abs(Math.sin( (i*30) + (Date.now() * 0.005) ))
      everything[i].style.opacity = `${phase}`
    }
  }, 33)
}
