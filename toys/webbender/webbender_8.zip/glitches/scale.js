() => {
  let everything = selectStuff()
  setInterval(() => {
    for(let i = 0; i < everything.length; i++) {
      let phase = Math.sin( (i*30) + (Date.now() * 0.005) )
      everything[i].style.transform = `scale(${phase})`
    }
  }, 33)
}
