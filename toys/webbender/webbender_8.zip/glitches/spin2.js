() => {
  // Find all the elements that usually have words
  let everything = document.querySelectorAll(
    ['a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'i'].join(', ')
  )

  let allWords = []
  // Wrap all the words on a span.wordxxx
  for (let i = 0; i < everything.length; i++) {
    let thing = everything[i]
    let text = thing.innerText.trim()
    let words = text.split(' ')
    words = words.filter(w => w)
    allWords = allWords.concat(words)
    let wrappedWords = words.map(w => `<span class="wordxxx">${w} </span>`)
    thing.innerHTML = wrappedWords.join('')
  }
  let el, hovering
  function onMouseMove(e) {
    let underTheMouse = document.elementsFromPoint(e.clientX, e.clientY)
    el = Array.from(underTheMouse).find(h => {
      return h.id !== 'appxxx' && h.id !== 'hovering'
    })
    if (!el) return false

    let bounds = el.getBoundingClientRect()
    hovering = document.querySelector('#hovering')
    if (!hovering) {
      hovering = document.createElement('div')
      hovering.id = 'hovering'
      hovering.style.position = 'absolute'
      hovering.style.transition = 'all 0.2s'
      hovering.style.background = 'rgba(255, 0, 0, 0.5)'
      hovering.style.pointer = 'none'
      let app = document.querySelector('#appxxx')
      app.appendChild(hovering)
    }

    hovering.style.top = `${bounds.top}px`
    hovering.style.left = `${bounds.left}px`
    hovering.style.width = `${bounds.width}px`
    hovering.style.height = `${bounds.height}px`
  }
  document.addEventListener('mousemove', onMouseMove)
  document.addEventListener('mousedown', (e) => {
    document.removeEventListener('mousemove', onMouseMove)
    hovering.remove()
    let t = 0
    setInterval(() => {
      el.style.display = 'inline-block'
      el.style.transform = `rotate(${t}deg)`
      t += 1
      t %= 360
    }, 33)
  }, { once: true })
}
